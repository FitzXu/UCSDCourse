let f = fun x -> fun y -> x + y in
let g = f 10 in
g 100
