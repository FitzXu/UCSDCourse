let decr = fun x -> x - 1 in
let m = [5;6;7;8] in
map decr m